import React from 'react'
import { LogOut, User, KeyRound, ChevronUp } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function ProfileMenu({ collapsed }) {
  const { profile, profileMenuOpen, setProfileMenuOpen, logout, t, setView } = useApp()
  const initials = profile.name
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)

  return (
    <div className="relative">
      {profileMenuOpen && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setProfileMenuOpen(false)} />
          <div
            className={`absolute bottom-14 z-20 w-56 overflow-hidden rounded-xl border border-stone-200 bg-white py-1.5 shadow-lg dark:border-slate-700 dark:bg-slate-800 ${
              collapsed ? 'left-14' : 'left-0'
            }`}
          >
            <div className="border-b border-stone-100 px-3.5 py-2.5 dark:border-slate-700">
              <p className="truncate text-sm font-semibold text-stone-800 dark:text-slate-100">{profile.name}</p>
              <p className="truncate text-xs text-stone-400 dark:text-slate-500">{profile.email}</p>
            </div>
            <button
              onClick={() => {
                setView('settings')
                setProfileMenuOpen(false)
              }}
              className="flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-sm text-stone-700 hover:bg-stone-100 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <User size={15} /> {t('profile')}
            </button>
            <button
              onClick={() => {
                setView('settings')
                setProfileMenuOpen(false)
              }}
              className="flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-sm text-stone-700 hover:bg-stone-100 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <KeyRound size={15} /> {t('changePassword')}
            </button>
            <button
              onClick={logout}
              className="flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-sm text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/40"
            >
              <LogOut size={15} /> {t('logout')}
            </button>
          </div>
        </>
      )}

      <button
        onClick={() => setProfileMenuOpen(!profileMenuOpen)}
        className={`flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-left hover:bg-stone-100 dark:hover:bg-slate-800 ${
          collapsed ? 'justify-center' : ''
        }`}
      >
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-600 text-xs font-bold text-white">
          {initials}
        </span>
        {!collapsed && (
          <>
            <span className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-stone-800 dark:text-slate-100">{profile.name}</p>
              <p className="truncate text-xs text-stone-400 dark:text-slate-500">{profile.department}</p>
            </span>
            <ChevronUp size={14} className={`text-stone-400 transition-transform ${profileMenuOpen ? '' : 'rotate-180'}`} />
          </>
        )}
      </button>
    </div>
  )
}
