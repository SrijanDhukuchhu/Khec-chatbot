import React, { useState } from 'react'
import { X, CheckCircle2 } from 'lucide-react'
import { useApp } from '../context/AppContext'

const REASON_KEYS = ['incorrectInfo', 'notRelevant', 'incompleteAnswer', 'incorrectSource', 'other']

export default function FeedbackModal() {
  const { feedbackModal, closeFeedbackModal, setMessageFeedback, t } = useApp()
  const [reason, setReason] = useState(null)
  const [note, setNote] = useState('')
  const [submitted, setSubmitted] = useState(false)

  if (!feedbackModal.open) return null

  const handleClose = () => {
    closeFeedbackModal()
    setTimeout(() => {
      setReason(null)
      setNote('')
      setSubmitted(false)
    }, 200)
  }

  const handleSubmit = () => {
    setMessageFeedback(feedbackModal.chatId, feedbackModal.messageId, 'dislike')
    setSubmitted(true)
    setTimeout(handleClose, 1300)
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-stone-200 bg-white p-5 shadow-xl animate-fadeUp dark:border-slate-700 dark:bg-slate-800">
        {submitted ? (
          <div className="flex flex-col items-center py-6 text-center">
            <CheckCircle2 size={32} className="text-brand-600 dark:text-brand-300" />
            <p className="mt-3 text-sm font-medium text-stone-700 dark:text-slate-200">{t('thanksFeedback')}</p>
          </div>
        ) : (
          <>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-stone-800 dark:text-slate-100">{t('whatWentWrong')}</h2>
              <button
                onClick={handleClose}
                className="rounded-md p-1 text-stone-400 hover:bg-stone-100 dark:hover:bg-slate-700"
                aria-label="Close"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-1.5">
              {REASON_KEYS.map((key) => (
                <button
                  key={key}
                  onClick={() => setReason(key)}
                  className={`flex w-full items-center gap-2.5 rounded-lg border px-3 py-2 text-left text-sm transition-colors ${
                    reason === key
                      ? 'border-brand-400 bg-brand-50 text-brand-700 dark:border-brand-500 dark:bg-brand-900/30 dark:text-brand-200'
                      : 'border-stone-200 text-stone-600 hover:bg-stone-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-700/50'
                  }`}
                >
                  <span
                    className={`h-3.5 w-3.5 shrink-0 rounded-full border-2 ${
                      reason === key ? 'border-brand-500 bg-brand-500' : 'border-stone-300 dark:border-slate-600'
                    }`}
                  />
                  {t(key)}
                </button>
              ))}
            </div>

            <label className="mt-3 block text-xs font-medium text-stone-500 dark:text-slate-400">
              {t('additionalFeedback')}
            </label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
              className="mt-1 w-full resize-none rounded-lg border border-stone-200 bg-white p-2.5 text-sm text-stone-700 placeholder:text-stone-400 focus:border-brand-400 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
              placeholder="Optional"
            />

            <button
              onClick={handleSubmit}
              disabled={!reason}
              className="mt-4 w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white transition-colors enabled:hover:bg-brand-700 disabled:cursor-not-allowed disabled:bg-stone-200 disabled:text-stone-400 dark:disabled:bg-slate-700"
            >
              {t('submitFeedback')}
            </button>
          </>
        )}
      </div>
    </div>
  )
}
