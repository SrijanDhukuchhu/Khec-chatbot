import React from 'react'
import { CheckCircle2 } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function Toast() {
  const { toast } = useApp()
  if (!toast) return null

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-6 z-[70] flex justify-center px-4">
      <div className="pointer-events-auto flex items-center gap-2 rounded-full border border-stone-200 bg-white px-4 py-2.5 text-sm font-medium text-stone-800 shadow-soft animate-fadeUp dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100">
        <CheckCircle2 size={16} className="text-brand-600 dark:text-brand-300" />
        {toast}
      </div>
    </div>
  )
}
