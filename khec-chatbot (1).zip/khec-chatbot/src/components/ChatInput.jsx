import React, { useRef, useState } from 'react'
import { Paperclip, ArrowUp } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function ChatInput() {
  const { sendMessage, isThinking, t } = useApp()
  const [value, setValue] = useState('')
  const [attached, setAttached] = useState(null)
  const fileRef = useRef(null)
  const taRef = useRef(null)

  const handleSend = () => {
    if (!value.trim() || isThinking) return
    sendMessage(value)
    setValue('')
    setAttached(null)
    if (taRef.current) taRef.current.style.height = 'auto'
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleInput = (e) => {
    setValue(e.target.value)
    const ta = e.target
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 160) + 'px'
  }

  return (
    <div className="border-t border-stone-200 bg-white/90 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur dark:border-slate-800 dark:bg-slate-900/90 sm:px-6 sm:pb-4">
      <div className="mx-auto max-w-3xl">
        {attached && (
          <div className="mb-2 flex w-fit items-center gap-2 rounded-lg border border-stone-200 bg-stone-50 px-3 py-1.5 text-xs text-stone-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
            <Paperclip size={12} />
            <span className="max-w-[180px] truncate">{attached}</span>
            <button onClick={() => setAttached(null)} className="text-stone-400 hover:text-stone-700 dark:hover:text-slate-100">
              ×
            </button>
          </div>
        )}

        <div className="flex items-end gap-2 rounded-2xl border border-stone-200 bg-white p-2 shadow-soft focus-within:border-brand-400 dark:border-slate-700 dark:bg-slate-800">
          <button
            onClick={() => fileRef.current?.click()}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-stone-400 hover:bg-stone-100 hover:text-stone-600 dark:hover:bg-slate-700 dark:hover:text-slate-200"
            title="Attach a file"
          >
            <Paperclip size={18} />
          </button>
          <input
            ref={fileRef}
            type="file"
            className="hidden"
            onChange={(e) => {
              if (e.target.files?.[0]) setAttached(e.target.files[0].name)
            }}
          />

          <textarea
            ref={taRef}
            rows={1}
            value={value}
            onChange={handleInput}
            onKeyDown={handleKeyDown}
            placeholder={t('inputPlaceholder')}
            className="max-h-40 flex-1 resize-none bg-transparent py-1.5 text-[15px] text-stone-800 placeholder:text-stone-400 focus:outline-none dark:text-slate-100 dark:placeholder:text-slate-500"
          />

          <button
            onClick={handleSend}
            disabled={!value.trim() || isThinking}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-brand-600 text-white transition-colors enabled:hover:bg-brand-700 disabled:cursor-not-allowed disabled:bg-stone-200 disabled:text-stone-400 dark:disabled:bg-slate-700 dark:disabled:text-slate-500"
            aria-label="Send message"
          >
            <ArrowUp size={18} />
          </button>
        </div>
        <p className="mt-2 text-center text-[11px] text-stone-400 dark:text-slate-600">{t('mockDataNotice')}</p>
      </div>
    </div>
  )
}
