import React, { useMemo, useState } from 'react'
import {
  PanelLeftClose,
  PanelLeftOpen,
  Plus,
  Search,
  Settings as SettingsIcon,
  HelpCircle,
  MessageSquare,
  X,
} from 'lucide-react'
import { useApp } from '../context/AppContext'
import Logo from './Logo'
import ProfileMenu from './ProfileMenu'

function NavItem({ icon: Icon, label, active, onClick, collapsed }) {
  return (
    <button
      onClick={onClick}
      title={collapsed ? label : undefined}
      className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
        active
          ? 'bg-brand-50 text-brand-700 dark:bg-brand-900/40 dark:text-brand-200'
          : 'text-stone-600 hover:bg-stone-100 dark:text-slate-300 dark:hover:bg-slate-800'
      } ${collapsed ? 'justify-center' : ''}`}
    >
      <Icon size={18} className="shrink-0" />
      {!collapsed && <span className="truncate">{label}</span>}
    </button>
  )
}

function SidebarContent({ collapsed, onNavigate }) {
  const { chats, activeChatId, openChat, startNewChat, view, setView, t, deleteChat, renameChat } = useApp()
  const [query, setQuery] = useState('')
  const [menuOpenId, setMenuOpenId] = useState(null)
  const [renamingId, setRenamingId] = useState(null)
  const [renameValue, setRenameValue] = useState('')

  const filtered = useMemo(() => {
    const sorted = [...chats].sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
    if (!query.trim()) return sorted.slice(0, 8)
    return sorted.filter((c) => c.title.toLowerCase().includes(query.toLowerCase()))
  }, [chats, query])

  const commitRename = (id) => {
    if (renameValue.trim()) renameChat(id, renameValue.trim())
    setRenamingId(null)
  }

  return (
    <div className="flex h-full flex-col">
      <div className={`flex items-center gap-2 px-3 pt-4 ${collapsed ? 'justify-center' : ''}`}>
        <Logo size={26} />
        {!collapsed && (
          <div className="min-w-0">
            <p className="truncate text-[15px] font-bold leading-tight text-brand-800 dark:text-brand-200">
              {t('appName')}
            </p>
          </div>
        )}
      </div>

      <div className="mt-4 px-3">
        <button
          onClick={() => {
            startNewChat()
            onNavigate?.()
          }}
          className={`flex w-full items-center gap-2 rounded-lg border border-stone-200 bg-white px-3 py-2 text-sm font-semibold text-brand-700 shadow-soft transition-colors hover:bg-brand-50 dark:border-slate-700 dark:bg-slate-900 dark:text-brand-200 dark:hover:bg-slate-800 ${
            collapsed ? 'justify-center' : ''
          }`}
        >
          <Plus size={17} />
          {!collapsed && t('newChat')}
        </button>
      </div>

      {!collapsed && (
        <div className="mt-3 px-3">
          <div className="flex items-center gap-2 rounded-lg border border-stone-200 bg-white px-2.5 py-1.5 focus-within:border-brand-400 dark:border-slate-700 dark:bg-slate-900">
            <Search size={15} className="text-stone-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t('searchConversations')}
              className="w-full bg-transparent text-sm text-stone-700 placeholder:text-stone-400 focus:outline-none dark:text-slate-200"
            />
          </div>
        </div>
      )}

      <div className="mt-4 flex-1 overflow-y-auto px-3">
        {!collapsed && (
          <p className="mb-1.5 px-1 text-xs font-semibold uppercase tracking-wide text-stone-400 dark:text-slate-500">
            {t('recent')}
          </p>
        )}
        <ul className="space-y-0.5">
          {filtered.map((chat) => (
            <li key={chat.id} className="group relative">
              {renamingId === chat.id ? (
                <input
                  autoFocus
                  value={renameValue}
                  onChange={(e) => setRenameValue(e.target.value)}
                  onBlur={() => commitRename(chat.id)}
                  onKeyDown={(e) => e.key === 'Enter' && commitRename(chat.id)}
                  className="w-full rounded-lg border border-brand-400 bg-white px-2.5 py-2 text-sm text-stone-800 focus:outline-none dark:bg-slate-900 dark:text-slate-100"
                />
              ) : (
                <button
                  onClick={() => {
                    openChat(chat.id)
                    onNavigate?.()
                  }}
                  title={collapsed ? chat.title : undefined}
                  className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm transition-colors ${
                    activeChatId === chat.id && view === 'chat'
                      ? 'bg-brand-50 text-brand-700 dark:bg-brand-900/40 dark:text-brand-200'
                      : 'text-stone-600 hover:bg-stone-100 dark:text-slate-300 dark:hover:bg-slate-800'
                  } ${collapsed ? 'justify-center' : ''}`}
                >
                  <MessageSquare size={16} className="shrink-0 opacity-70" />
                  {!collapsed && <span className="min-w-0 flex-1 truncate">{chat.title}</span>}
                </button>
              )}

              {!collapsed && renamingId !== chat.id && (
                <div className="absolute right-1 top-1/2 hidden -translate-y-1/2 group-hover:block">
                  <ChatMenu
                    onRename={() => {
                      setRenamingId(chat.id)
                      setRenameValue(chat.title)
                    }}
                    onDelete={() => deleteChat(chat.id)}
                    open={menuOpenId === chat.id}
                    setOpen={(v) => setMenuOpenId(v ? chat.id : null)}
                    t={t}
                  />
                </div>
              )}
            </li>
          ))}
          {filtered.length === 0 && !collapsed && (
            <p className="px-2 py-3 text-sm text-stone-400 dark:text-slate-500">{t('noResults')}</p>
          )}
        </ul>
      </div>

      <div className="border-t border-stone-200 px-3 py-2 dark:border-slate-800">
        <NavItem
          icon={SettingsIcon}
          label={t('settings')}
          active={view === 'settings'}
          collapsed={collapsed}
          onClick={() => {
            setView('settings')
            onNavigate?.()
          }}
        />
        <NavItem
          icon={HelpCircle}
          label={t('help')}
          collapsed={collapsed}
          onClick={() => alert('KHEC Chatbot prototype — help center coming soon.')}
        />
      </div>

      <div className="border-t border-stone-200 p-3 dark:border-slate-800">
        <ProfileMenu collapsed={collapsed} />
      </div>
    </div>
  )
}

function ChatMenu({ onRename, onDelete, open, setOpen, t }) {
  return (
    <div className="relative">
      <button
        onClick={(e) => {
          e.stopPropagation()
          setOpen(!open)
        }}
        className="rounded-md p-1 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:hover:bg-slate-700 dark:hover:text-slate-100"
        aria-label="Chat options"
      >
        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
          <circle cx="8" cy="3" r="1.4" />
          <circle cx="8" cy="8" r="1.4" />
          <circle cx="8" cy="13" r="1.4" />
        </svg>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-7 z-20 w-32 overflow-hidden rounded-lg border border-stone-200 bg-white py-1 shadow-lg dark:border-slate-700 dark:bg-slate-800">
            <button
              onClick={() => {
                onRename()
                setOpen(false)
              }}
              className="block w-full px-3 py-1.5 text-left text-sm text-stone-700 hover:bg-stone-100 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              {t('rename')}
            </button>
            <button
              onClick={() => {
                onDelete()
                setOpen(false)
              }}
              className="block w-full px-3 py-1.5 text-left text-sm text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/40"
            >
              {t('delete')}
            </button>
          </div>
        </>
      )}
    </div>
  )
}

export default function Sidebar() {
  const { sidebarCollapsed, setSidebarCollapsed, mobileSidebarOpen, setMobileSidebarOpen, t } = useApp()

  return (
    <>
      {/* Desktop / tablet sidebar */}
      <aside
        className={`relative hidden shrink-0 border-r border-stone-200 bg-white transition-[width] duration-200 dark:border-slate-800 dark:bg-slate-900 md:flex ${
          sidebarCollapsed ? 'w-[72px]' : 'w-[260px]'
        }`}
      >
        <SidebarContent collapsed={sidebarCollapsed} />
        <button
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          title={sidebarCollapsed ? t('expand') : t('collapse')}
          className="absolute -right-3 top-6 flex h-6 w-6 items-center justify-center rounded-full border border-stone-200 bg-white text-stone-500 shadow-soft hover:text-brand-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400"
        >
          {sidebarCollapsed ? <PanelLeftOpen size={13} /> : <PanelLeftClose size={13} />}
        </button>
      </aside>

      {/* Mobile drawer */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setMobileSidebarOpen(false)} />
          <div className="relative flex h-full w-[280px] max-w-[85vw] flex-col bg-white shadow-xl animate-slideInLeft dark:bg-slate-900">
            <button
              onClick={() => setMobileSidebarOpen(false)}
              className="absolute right-3 top-3 rounded-md p-1.5 text-stone-500 hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-800"
              aria-label="Close menu"
            >
              <X size={18} />
            </button>
            <SidebarContent collapsed={false} onNavigate={() => setMobileSidebarOpen(false)} />
          </div>
        </div>
      )}
    </>
  )
}
