import React from 'react'

// Custom mark: a stylised tiered pagoda roof (nods to Nepali/Newari architecture
// around Bhaktapur, where KHEC is located) rendered as simple geometric strokes,
// paired with a small terracotta finial dot. Used instead of a generic chat-bubble
// or graduation-cap icon so the brand reads as specific to KHEC rather than templated.
export default function Logo({ size = 28, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <rect x="2" y="21" width="28" height="2.4" rx="1.2" className="fill-brand-700 dark:fill-brand-300" />
      <rect x="5" y="15.5" width="22" height="2.2" rx="1.1" className="fill-brand-600 dark:fill-brand-400" />
      <rect x="8" y="10" width="16" height="2" rx="1" className="fill-brand-500 dark:fill-brand-400" />
      <rect x="14.2" y="4.5" width="3.6" height="7" rx="1" className="fill-brand-700 dark:fill-brand-200" />
      <circle cx="16" cy="3.2" r="2" className="fill-terracotta-400" />
    </svg>
  )
}
