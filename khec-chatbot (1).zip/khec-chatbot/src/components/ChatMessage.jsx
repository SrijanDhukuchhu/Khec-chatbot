import React, { useState } from 'react'
import { ThumbsUp, ThumbsDown, Copy, RefreshCcw, Check, Layers, SearchX } from 'lucide-react'
import { useApp } from '../context/AppContext'
import SourceCard from './SourceCard'
import { fallbackTopics } from '../data/mockData'

function IconButton({ children, active, onClick, activeClass, title }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`flex items-center gap-1.5 rounded-md px-2 py-1 text-xs font-medium transition-colors ${
        active
          ? activeClass
          : 'text-stone-400 hover:bg-stone-100 hover:text-stone-600 dark:text-slate-500 dark:hover:bg-slate-800 dark:hover:text-slate-300'
      }`}
    >
      {children}
    </button>
  )
}

export default function ChatMessage({ chatId, message }) {
  const { t, showSources, setMessageFeedback, openFeedbackModal, regenerateResponse, openSourcePanel, showToast } =
    useApp()
  const [copied, setCopied] = useState(false)

  const isUser = message.role === 'user'

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.text)
    } catch {
      // clipboard may be unavailable in the sandbox — fail silently
    }
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const handleLike = () => {
    const next = message.feedback === 'like' ? null : 'like'
    setMessageFeedback(chatId, message.id, next)
    if (next === 'like') showToast(t('thanksFeedback'))
  }

  const handleDislike = () => {
    if (message.feedback === 'dislike') {
      setMessageFeedback(chatId, message.id, null)
      return
    }
    openFeedbackModal(chatId, message.id)
  }

  if (isUser) {
    return (
      <div className="flex justify-end px-1">
        <div className="max-w-[85%] rounded-2xl rounded-tr-sm bg-brand-600 px-4 py-2.5 text-[15px] leading-relaxed text-white shadow-soft sm:max-w-[70%]">
          {message.text}
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-start gap-3 px-1">
      <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-50 dark:bg-brand-900/50">
        <svg width="14" height="14" viewBox="0 0 32 32" fill="none">
          <rect x="2" y="21" width="28" height="2.4" rx="1.2" className="fill-brand-700 dark:fill-brand-300" />
          <rect x="5" y="15.5" width="22" height="2.2" rx="1.1" className="fill-brand-600 dark:fill-brand-400" />
          <rect x="8" y="10" width="16" height="2" rx="1" className="fill-brand-500 dark:fill-brand-400" />
          <rect x="14.2" y="4.5" width="3.6" height="7" rx="1" className="fill-brand-700 dark:fill-brand-200" />
          <circle cx="16" cy="3.2" r="2" className="fill-terracotta-400" />
        </svg>
      </span>

      <div className="min-w-0 max-w-[85%] sm:max-w-[75%]">
        <div
          className={`rounded-2xl rounded-tl-sm border px-4 py-3 text-[15px] leading-relaxed shadow-soft ${
            message.isFallback
              ? 'border-terracotta-200 bg-terracotta-50/60 text-stone-700 dark:border-terracotta-600/40 dark:bg-terracotta-900/10 dark:text-slate-200'
              : 'border-stone-200 bg-white text-stone-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
          }`}
        >
          {message.isFallback && (
            <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-terracotta-500">
              <SearchX size={13} /> {t('appName')}
            </div>
          )}
          <p className="whitespace-pre-wrap">{message.text}</p>

          {message.isFallback && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {fallbackTopics.map((topic) => (
                <span
                  key={topic}
                  className="rounded-full border border-stone-200 bg-white px-2.5 py-1 text-xs font-medium text-stone-500 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-400"
                >
                  {topic}
                </span>
              ))}
            </div>
          )}
        </div>

        {!message.isFallback && showSources && message.sources && message.sources.length > 0 && (
          <div className="mt-2 space-y-1.5">
            <p className="px-0.5 text-[11px] font-semibold uppercase tracking-wide text-stone-400 dark:text-slate-500">
              {t('sources')}
            </p>
            <div className="grid gap-1.5 sm:grid-cols-2">
              {message.sources.slice(0, 2).map((s, i) => (
                <SourceCard key={i} source={s} compact />
              ))}
            </div>
            <button
              onClick={() => openSourcePanel(message.sources, message.text)}
              className="flex items-center gap-1.5 rounded-md px-0.5 py-1 text-xs font-semibold text-brand-600 hover:underline dark:text-brand-300"
            >
              <Layers size={13} /> {t('viewSources')}
            </button>
          </div>
        )}

        <div className="mt-1.5 flex items-center gap-0.5">
          <IconButton
            title={t('like')}
            active={message.feedback === 'like'}
            activeClass="text-brand-600 bg-brand-50 dark:text-brand-300 dark:bg-brand-900/40"
            onClick={handleLike}
          >
            <ThumbsUp size={13} />
          </IconButton>
          <IconButton
            title={t('dislike')}
            active={message.feedback === 'dislike'}
            activeClass="text-terracotta-500 bg-terracotta-50 dark:bg-terracotta-900/20"
            onClick={handleDislike}
          >
            <ThumbsDown size={13} />
          </IconButton>
          <IconButton title={copied ? t('copied') : t('copy')} onClick={handleCopy}>
            {copied ? <Check size={13} /> : <Copy size={13} />}
          </IconButton>
          <IconButton title={t('regenerate')} onClick={() => regenerateResponse(chatId, message.id)}>
            <RefreshCcw size={13} />
          </IconButton>
        </div>
      </div>
    </div>
  )
}
