import React from 'react'
import { Menu, Languages, Sun, Moon } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function Header() {
  const { setMobileSidebarOpen, t, language, setLanguage, view, activeChat, setThemePref, effectiveTheme } =
    useApp()

  const titleMap = {
    chat: activeChat ? activeChat.title : t('appName'),
    history: t('chatHistory'),
    settings: t('settings'),
  }

  return (
    <header className="flex h-14 shrink-0 items-center justify-between gap-3 border-b border-stone-200 bg-white/80 px-3 backdrop-blur dark:border-slate-800 dark:bg-slate-900/80 sm:px-5">
      <div className="flex min-w-0 items-center gap-2">
        <button
          onClick={() => setMobileSidebarOpen(true)}
          className="rounded-md p-1.5 text-stone-500 hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-800 md:hidden"
          aria-label="Open menu"
        >
          <Menu size={20} />
        </button>
        <h1 className="min-w-0 truncate text-sm font-semibold text-stone-700 dark:text-slate-200 sm:text-[15px]">
          {titleMap[view]}
        </h1>
      </div>

      <div className="flex shrink-0 items-center gap-1.5">
        <button
          onClick={() => setThemePref(effectiveTheme === 'dark' ? 'light' : 'dark')}
          className="rounded-lg p-2 text-stone-500 hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-800"
          aria-label="Toggle theme"
          title={effectiveTheme === 'dark' ? t('light') : t('dark')}
        >
          {effectiveTheme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
        </button>

        <div className="flex items-center gap-1 rounded-lg border border-stone-200 p-0.5 text-xs font-medium dark:border-slate-700">
          <Languages size={13} className="ml-1.5 text-stone-400" />
          <button
            onClick={() => setLanguage('en')}
            className={`rounded-md px-2 py-1 transition-colors ${
              language === 'en'
                ? 'bg-brand-600 text-white'
                : 'text-stone-500 hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-800'
            }`}
          >
            EN
          </button>
          <button
            onClick={() => setLanguage('ne')}
            className={`rounded-md px-2 py-1 transition-colors ${
              language === 'ne'
                ? 'bg-brand-600 text-white'
                : 'text-stone-500 hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-800'
            }`}
          >
            नेपाली
          </button>
        </div>
      </div>
    </header>
  )
}
