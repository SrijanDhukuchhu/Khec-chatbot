import React, { useEffect, useRef } from 'react'
import { useApp } from '../context/AppContext'
import Logo from './Logo'
import SuggestedQuestion from './SuggestedQuestion'
import ChatMessage from './ChatMessage'
import ChatInput from './ChatInput'
import TypingIndicator from './TypingIndicator'
import { suggestedQuestions } from '../data/mockData'

export default function ChatWindow() {
  const { activeChat, sendMessage, isThinking, t, language } = useApp()
  const scrollRef = useRef(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [activeChat?.messages?.length, isThinking])

  const hasMessages = activeChat && activeChat.messages.length > 0

  if (!hasMessages) {
    return (
      <div className="flex h-full flex-col">
        <div className="pagoda-mark flex flex-1 flex-col items-center justify-center overflow-y-auto px-4 py-10">
          <div className="w-full max-w-2xl text-center">
            <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-50 shadow-soft dark:bg-brand-900/40">
              <Logo size={30} />
            </span>
            <h1 className="mt-5 text-2xl font-bold tracking-tight text-stone-800 dark:text-slate-100 sm:text-3xl">
              {t('welcomeHeading')}
            </h1>
            <p className="mt-2 text-[15px] text-stone-500 dark:text-slate-400">{t('welcomeSubheading')}</p>

            <div className="mt-8 grid grid-cols-1 gap-3 text-left sm:grid-cols-2">
              {suggestedQuestions.map((item) => (
                <SuggestedQuestion
                  key={item.id}
                  item={item}
                  label={language === 'ne' ? item.labelNe : item.label}
                  question={language === 'ne' ? item.questionNe : item.question}
                  onClick={() => sendMessage(language === 'ne' ? item.questionNe : item.question)}
                />
              ))}
            </div>
          </div>
        </div>
        <ChatInput />
      </div>
    )
  }

  return (
    <div className="flex h-full flex-col">
      <div ref={scrollRef} className="chat-scroll flex-1 overflow-y-auto px-3 py-6 sm:px-6">
        <div className="mx-auto flex max-w-3xl flex-col gap-5">
          {activeChat.messages.map((m) => (
            <ChatMessage key={m.id} chatId={activeChat.id} message={m} />
          ))}
          {isThinking && <TypingIndicator />}
        </div>
      </div>
      <ChatInput />
    </div>
  )
}
