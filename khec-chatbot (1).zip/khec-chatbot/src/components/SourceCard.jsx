import React from 'react'
import { FileText, ExternalLink } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function SourceCard({ source, compact = false }) {
  const { t } = useApp()

  if (compact) {
    return (
      <div className="flex items-start gap-2 rounded-lg border border-stone-200 bg-stone-50 px-2.5 py-2 text-xs text-stone-600 dark:border-slate-700 dark:bg-slate-800/60 dark:text-slate-300">
        <FileText size={13} className="mt-0.5 shrink-0 text-brand-600 dark:text-brand-300" />
        <span className="min-w-0 truncate">
          {source.title} · {t('page')} {source.page}
        </span>
      </div>
    )
  }

  return (
    <div className="rounded-xl border border-stone-200 bg-white p-3.5 dark:border-slate-700 dark:bg-slate-800">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-start gap-2.5">
          <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-brand-50 text-brand-600 dark:bg-brand-900/40 dark:text-brand-300">
            <FileText size={14} />
          </span>
          <div>
            <p className="text-sm font-semibold leading-snug text-stone-800 dark:text-slate-100">{source.title}</p>
            <p className="mt-0.5 text-xs text-stone-400 dark:text-slate-500">
              {t('page')} {source.page} · {source.type}
            </p>
          </div>
        </div>
        <button
          className="shrink-0 rounded-md p-1.5 text-stone-400 hover:bg-stone-100 hover:text-brand-600 dark:hover:bg-slate-700 dark:hover:text-brand-300"
          title="View source"
          onClick={() => alert('This is a mock source for the prototype — no live document is linked yet.')}
        >
          <ExternalLink size={14} />
        </button>
      </div>
      <p className="mt-2.5 rounded-lg bg-stone-50 p-2.5 text-xs italic leading-relaxed text-stone-500 dark:bg-slate-900/60 dark:text-slate-400">
        "{source.excerpt}"
      </p>
    </div>
  )
}
