import React from 'react'
import { GraduationCap, CalendarDays, BookOpen, Wallet } from 'lucide-react'

const iconMap = { GraduationCap, CalendarDays, BookOpen, Wallet }

export default function SuggestedQuestion({ item, label, question, onClick }) {
  const Icon = iconMap[item.icon] || GraduationCap
  return (
    <button
      onClick={onClick}
      className="group flex flex-col items-start gap-2.5 rounded-xl border border-stone-200 bg-white p-4 text-left shadow-soft transition-all hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-md dark:border-slate-700 dark:bg-slate-800 dark:hover:border-brand-500/50"
    >
      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-50 text-brand-600 group-hover:bg-brand-100 dark:bg-brand-900/40 dark:text-brand-300 dark:group-hover:bg-brand-900/70">
        <Icon size={18} />
      </span>
      <div>
        <p className="text-sm font-semibold text-stone-800 dark:text-slate-100">{label}</p>
        <p className="mt-0.5 text-sm text-stone-500 dark:text-slate-400">{question}</p>
      </div>
    </button>
  )
}
