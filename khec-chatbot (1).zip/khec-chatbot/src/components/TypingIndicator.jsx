import React from 'react'
import Logo from './Logo'
import { useApp } from '../context/AppContext'

export default function TypingIndicator() {
  const { t } = useApp()
  return (
    <div className="flex items-start gap-3 px-1">
      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-50 dark:bg-brand-900/50">
        <Logo size={16} />
      </span>
      <div className="flex items-center gap-2 rounded-2xl rounded-tl-sm border border-stone-200 bg-white px-4 py-3 text-sm text-stone-400 shadow-soft dark:border-slate-700 dark:bg-slate-800 dark:text-slate-500">
        <span className="flex gap-1">
          <span className="h-1.5 w-1.5 animate-blink rounded-full bg-stone-400 [animation-delay:-0.32s] dark:bg-slate-500" />
          <span className="h-1.5 w-1.5 animate-blink rounded-full bg-stone-400 [animation-delay:-0.16s] dark:bg-slate-500" />
          <span className="h-1.5 w-1.5 animate-blink rounded-full bg-stone-400 dark:bg-slate-500" />
        </span>
        <span>{t('thinking')}</span>
      </div>
    </div>
  )
}
