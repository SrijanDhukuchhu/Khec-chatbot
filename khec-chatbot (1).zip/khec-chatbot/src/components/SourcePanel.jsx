import React from 'react'
import { X, Layers } from 'lucide-react'
import { useApp } from '../context/AppContext'
import SourceCard from './SourceCard'

export default function SourcePanel() {
  const { sourcePanel, closeSourcePanel, t } = useApp()

  if (!sourcePanel.open) return null

  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/30 lg:hidden" onClick={closeSourcePanel} />
      <aside className="fixed inset-y-0 right-0 z-50 flex w-full max-w-[380px] flex-col border-l border-stone-200 bg-white shadow-panel animate-slideIn dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between border-b border-stone-200 px-4 py-3.5 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Layers size={16} className="text-brand-600 dark:text-brand-300" />
            <h2 className="text-sm font-semibold text-stone-800 dark:text-slate-100">{t('sources')}</h2>
          </div>
          <button
            onClick={closeSourcePanel}
            className="rounded-md p-1.5 text-stone-400 hover:bg-stone-100 dark:hover:bg-slate-800"
            aria-label="Close panel"
          >
            <X size={17} />
          </button>
        </div>

        <div className="border-b border-stone-100 bg-brand-50/60 px-4 py-3 text-xs leading-relaxed text-brand-800 dark:border-slate-800 dark:bg-brand-900/20 dark:text-brand-200">
          These passages were retrieved from the KHEC knowledge base and used to ground the answer above — a
          preview of how the production system's retrieval-augmented generation (RAG) pipeline will cite its
          sources.
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {sourcePanel.sources.map((s, i) => (
            <SourceCard key={i} source={s} />
          ))}
        </div>
      </aside>
    </>
  )
}
