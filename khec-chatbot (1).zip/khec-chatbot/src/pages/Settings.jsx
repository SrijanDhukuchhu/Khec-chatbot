import React, { useState } from 'react'
import { User, KeyRound, LogOut, Sun, Moon, Laptop, Check } from 'lucide-react'
import { useApp } from '../context/AppContext'

function Toggle({ checked, onChange, label }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${
        checked ? 'bg-brand-600' : 'bg-stone-200 dark:bg-slate-700'
      }`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
          checked ? 'translate-x-[22px]' : 'translate-x-0.5'
        }`}
      />
    </button>
  )
}

function SectionCard({ title, children }) {
  return (
    <div className="mb-6 overflow-hidden rounded-xl border border-stone-200 bg-white shadow-soft dark:border-slate-700 dark:bg-slate-800">
      <p className="border-b border-stone-100 px-4 py-3 text-xs font-semibold uppercase tracking-wide text-stone-400 dark:border-slate-700 dark:text-slate-500">
        {title}
      </p>
      <div className="divide-y divide-stone-100 dark:divide-slate-700">{children}</div>
    </div>
  )
}

function Row({ label, description, control }) {
  return (
    <div className="flex items-center justify-between gap-4 px-4 py-3.5">
      <div className="min-w-0">
        <p className="text-sm font-medium text-stone-800 dark:text-slate-100">{label}</p>
        {description && <p className="mt-0.5 text-xs text-stone-400 dark:text-slate-500">{description}</p>}
      </div>
      {control}
    </div>
  )
}

export default function Settings() {
  const {
    t,
    language,
    setLanguage,
    themePref,
    setThemePref,
    showSources,
    setShowSources,
    saveHistory,
    setSaveHistory,
    profile,
    logout,
    showToast,
  } = useApp()

  const [editing, setEditing] = useState(false)
  const [name, setName] = useState(profile.name)

  const themeOptions = [
    { id: 'light', label: t('light'), icon: Sun },
    { id: 'dark', label: t('dark'), icon: Moon },
    { id: 'system', label: t('system'), icon: Laptop },
  ]

  return (
    <div className="h-full overflow-y-auto px-4 py-6 sm:px-8">
      <div className="mx-auto max-w-2xl">
        <SectionCard title={t('general')}>
          <Row
            label={t('language')}
            control={
              <div className="flex items-center gap-1 rounded-lg border border-stone-200 p-0.5 text-xs font-medium dark:border-slate-700">
                {[
                  { id: 'en', label: 'English' },
                  { id: 'ne', label: 'नेपाली' },
                ].map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setLanguage(opt.id)}
                    className={`rounded-md px-2.5 py-1.5 ${
                      language === opt.id
                        ? 'bg-brand-600 text-white'
                        : 'text-stone-500 hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-700'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            }
          />
          <Row
            label={t('theme')}
            control={
              <div className="flex items-center gap-1 rounded-lg border border-stone-200 p-0.5 dark:border-slate-700">
                {themeOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setThemePref(opt.id)}
                    title={opt.label}
                    className={`flex h-7 w-7 items-center justify-center rounded-md ${
                      themePref === opt.id
                        ? 'bg-brand-600 text-white'
                        : 'text-stone-500 hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-700'
                    }`}
                  >
                    <opt.icon size={14} />
                  </button>
                ))}
              </div>
            }
          />
        </SectionCard>

        <SectionCard title={t('chat')}>
          <Row label={t('showSources')} control={<Toggle checked={showSources} onChange={setShowSources} label={t('showSources')} />} />
          <Row
            label={t('saveChatHistory')}
            control={<Toggle checked={saveHistory} onChange={setSaveHistory} label={t('saveChatHistory')} />}
          />
        </SectionCard>

        <SectionCard title={t('account')}>
          <div className="flex items-center gap-3 px-4 py-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brand-600 text-sm font-bold text-white">
              {profile.name.split(' ').map((p) => p[0]).join('').slice(0, 2)}
            </span>
            <div className="min-w-0 flex-1">
              {editing ? (
                <input
                  autoFocus
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onBlur={() => setEditing(false)}
                  onKeyDown={(e) => e.key === 'Enter' && setEditing(false)}
                  className="w-full rounded-md border border-brand-400 bg-white px-2 py-1 text-sm font-semibold text-stone-800 focus:outline-none dark:bg-slate-900 dark:text-slate-100"
                />
              ) : (
                <p className="truncate text-sm font-semibold text-stone-800 dark:text-slate-100">{name}</p>
              )}
              <p className="truncate text-xs text-stone-400 dark:text-slate-500">{profile.email}</p>
              <p className="mt-0.5 text-xs text-stone-400 dark:text-slate-500">
                {t('student')} · {profile.department}
              </p>
            </div>
            <button
              onClick={() => setEditing((v) => !v)}
              className="shrink-0 rounded-lg border border-stone-200 px-2.5 py-1.5 text-xs font-semibold text-stone-600 hover:bg-stone-50 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700"
            >
              {editing ? (
                <span className="flex items-center gap-1">
                  <Check size={12} /> {t('save')}
                </span>
              ) : (
                t('editProfile')
              )}
            </button>
          </div>

          <button
            onClick={() => showToast(language === 'ne' ? 'पासवर्ड परिवर्तन गरियो' : 'Password updated')}
            className="flex w-full items-center gap-2.5 px-4 py-3.5 text-left text-sm font-medium text-stone-700 hover:bg-stone-50 dark:text-slate-200 dark:hover:bg-slate-700/50"
          >
            <KeyRound size={16} className="text-stone-400" /> {t('changePassword')}
          </button>
          <button
            onClick={() => showToast(language === 'ne' ? 'प्रोफाइल अद्यावधिक भयो' : 'Profile updated')}
            className="flex w-full items-center gap-2.5 px-4 py-3.5 text-left text-sm font-medium text-stone-700 hover:bg-stone-50 dark:text-slate-200 dark:hover:bg-slate-700/50"
          >
            <User size={16} className="text-stone-400" /> {t('editProfile')}
          </button>
          <button
            onClick={logout}
            className="flex w-full items-center gap-2.5 px-4 py-3.5 text-left text-sm font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/40"
          >
            <LogOut size={16} /> {t('logout')}
          </button>
        </SectionCard>
      </div>
    </div>
  )
}
