import React, { useState } from 'react'
import { Eye, EyeOff, ArrowRight } from 'lucide-react'
import { useApp } from '../context/AppContext'
import Logo from '../components/Logo'

export default function Login() {
  const { login, t, language, setLanguage } = useApp()
  const [showPw, setShowPw] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    // Prototype: any input logs the user in — no real authentication is performed.
    login()
  }

  return (
    <div className="pagoda-mark flex min-h-[100dvh] items-center justify-center bg-stone-50 px-4 dark:bg-slate-950">
      <div className="absolute right-4 top-4 flex items-center gap-1 rounded-lg border border-stone-200 bg-white p-0.5 text-xs font-medium shadow-soft dark:border-slate-700 dark:bg-slate-900">
        <button
          onClick={() => setLanguage('en')}
          className={`rounded-md px-2.5 py-1.5 ${
            language === 'en' ? 'bg-brand-600 text-white' : 'text-stone-500 dark:text-slate-400'
          }`}
        >
          EN
        </button>
        <button
          onClick={() => setLanguage('ne')}
          className={`rounded-md px-2.5 py-1.5 ${
            language === 'ne' ? 'bg-brand-600 text-white' : 'text-stone-500 dark:text-slate-400'
          }`}
        >
          नेपाली
        </button>
      </div>

      <div className="w-full max-w-sm">
        <div className="mb-7 flex flex-col items-center text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white shadow-soft dark:bg-slate-900">
            <Logo size={30} />
          </span>
          <h1 className="mt-4 text-xl font-bold text-stone-800 dark:text-slate-100">{t('loginHeading')}</h1>
          <p className="mt-1.5 text-sm text-stone-500 dark:text-slate-400">{t('appSubtitle')}</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-2xl border border-stone-200 bg-white p-6 shadow-soft dark:border-slate-800 dark:bg-slate-900"
        >
          <p className="mb-4 text-center text-xs text-stone-400 dark:text-slate-500">{t('signIn')}</p>

          <label className="mb-1.5 block text-xs font-medium text-stone-500 dark:text-slate-400">
            {t('emailUsername')}
          </label>
          <input
            required
            type="text"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@khec.edu.np"
            className="mb-4 w-full rounded-lg border border-stone-200 bg-white px-3 py-2.5 text-sm text-stone-800 placeholder:text-stone-400 focus:border-brand-400 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
          />

          <label className="mb-1.5 block text-xs font-medium text-stone-500 dark:text-slate-400">
            {t('password')}
          </label>
          <div className="relative mb-5">
            <input
              required
              type={showPw ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full rounded-lg border border-stone-200 bg-white px-3 py-2.5 pr-10 text-sm text-stone-800 placeholder:text-stone-400 focus:border-brand-400 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
            <button
              type="button"
              onClick={() => setShowPw(!showPw)}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 dark:hover:text-slate-200"
              tabIndex={-1}
            >
              {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>

          <button
            type="submit"
            className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-brand-700"
          >
            {t('login')} <ArrowRight size={15} />
          </button>
        </form>

        <p className="mt-4 text-center text-sm text-stone-500 dark:text-slate-400">
          {t('noAccount')}{' '}
          <button onClick={login} className="font-semibold text-brand-600 hover:underline dark:text-brand-300">
            {t('signUp')}
          </button>
        </p>
      </div>
    </div>
  )
}
