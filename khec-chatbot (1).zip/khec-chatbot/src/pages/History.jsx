import React, { useMemo, useState } from 'react'
import { Search, MessageSquare, MoreHorizontal } from 'lucide-react'
import { useApp } from '../context/AppContext'

function isSameDay(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()
}

function groupChats(chats) {
  const now = new Date()
  const yesterday = new Date(now)
  yesterday.setDate(now.getDate() - 1)

  const groups = { today: [], yesterday: [], previous7: [], previous30: [], older: [] }

  chats.forEach((chat) => {
    const d = new Date(chat.updatedAt)
    const diffDays = Math.floor((now - d) / (1000 * 60 * 60 * 24))
    if (isSameDay(d, now)) groups.today.push(chat)
    else if (isSameDay(d, yesterday)) groups.yesterday.push(chat)
    else if (diffDays <= 7) groups.previous7.push(chat)
    else if (diffDays <= 30) groups.previous30.push(chat)
    else groups.older.push(chat)
  })

  return groups
}

function Highlight({ text, query }) {
  if (!query.trim()) return <>{text}</>
  const idx = text.toLowerCase().indexOf(query.toLowerCase())
  if (idx === -1) return <>{text}</>
  return (
    <>
      {text.slice(0, idx)}
      <mark className="rounded bg-terracotta-100 px-0.5 text-terracotta-600 dark:bg-terracotta-500/20 dark:text-terracotta-300">
        {text.slice(idx, idx + query.length)}
      </mark>
      {text.slice(idx + query.length)}
    </>
  )
}

function formatDate(iso, t) {
  const d = new Date(iso)
  const now = new Date()
  const time = d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })
  if (isSameDay(d, now)) return time
  return `${d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} · ${time}`
}

function Row({ chat, query, onOpen, onRename, onDelete, t }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [renaming, setRenaming] = useState(false)
  const [value, setValue] = useState(chat.title)

  const commit = () => {
    if (value.trim()) onRename(chat.id, value.trim())
    setRenaming(false)
  }

  return (
    <li className="group flex items-center gap-3 rounded-xl border border-stone-200 bg-white px-3.5 py-3 shadow-soft dark:border-slate-700 dark:bg-slate-800">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-600 dark:bg-brand-900/40 dark:text-brand-300">
        <MessageSquare size={16} />
      </span>

      {renaming ? (
        <input
          autoFocus
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onBlur={commit}
          onKeyDown={(e) => e.key === 'Enter' && commit()}
          className="min-w-0 flex-1 rounded-md border border-brand-400 bg-white px-2 py-1.5 text-sm text-stone-800 focus:outline-none dark:bg-slate-900 dark:text-slate-100"
        />
      ) : (
        <button onClick={() => onOpen(chat.id)} className="min-w-0 flex-1 text-left">
          <p className="truncate text-sm font-semibold text-stone-800 dark:text-slate-100">
            <Highlight text={chat.title} query={query} />
          </p>
          <p className="text-xs text-stone-400 dark:text-slate-500">{formatDate(chat.updatedAt, t)}</p>
        </button>
      )}

      <div className="relative shrink-0">
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="rounded-md p-1.5 text-stone-400 opacity-0 hover:bg-stone-100 hover:text-stone-700 group-hover:opacity-100 dark:hover:bg-slate-700 dark:hover:text-slate-100"
          aria-label="Conversation options"
        >
          <MoreHorizontal size={17} />
        </button>
        {menuOpen && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
            <div className="absolute right-0 top-9 z-20 w-32 overflow-hidden rounded-lg border border-stone-200 bg-white py-1 shadow-lg dark:border-slate-700 dark:bg-slate-800">
              <button
                onClick={() => {
                  setRenaming(true)
                  setMenuOpen(false)
                }}
                className="block w-full px-3 py-1.5 text-left text-sm text-stone-700 hover:bg-stone-100 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                {t('rename')}
              </button>
              <button
                onClick={() => {
                  onDelete(chat.id)
                  setMenuOpen(false)
                }}
                className="block w-full px-3 py-1.5 text-left text-sm text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/40"
              >
                {t('delete')}
              </button>
            </div>
          </>
        )}
      </div>
    </li>
  )
}

function Section({ title, chats, ...rest }) {
  if (chats.length === 0) return null
  return (
    <div className="mb-6">
      <p className="mb-2 px-0.5 text-xs font-semibold uppercase tracking-wide text-stone-400 dark:text-slate-500">
        {title}
      </p>
      <ul className="space-y-2">
        {chats.map((chat) => (
          <Row key={chat.id} chat={chat} {...rest} />
        ))}
      </ul>
    </div>
  )
}

export default function History() {
  const { chats, openChat, deleteChat, renameChat, t } = useApp()
  const [query, setQuery] = useState('')

  const filtered = useMemo(() => {
    if (!query.trim()) return chats
    return chats.filter((c) => c.title.toLowerCase().includes(query.toLowerCase()))
  }, [chats, query])

  const groups = useMemo(() => groupChats(filtered), [filtered])

  const rowProps = { query, onOpen: openChat, onRename: renameChat, onDelete: deleteChat, t }

  return (
    <div className="h-full overflow-y-auto px-4 py-6 sm:px-8">
      <div className="mx-auto max-w-2xl">
        <div className="mb-5 flex items-center gap-2 rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 shadow-soft dark:border-slate-700 dark:bg-slate-800">
          <Search size={16} className="text-stone-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('searchConversations')}
            className="w-full bg-transparent text-sm text-stone-700 placeholder:text-stone-400 focus:outline-none dark:text-slate-200"
          />
        </div>

        {filtered.length === 0 ? (
          <p className="py-16 text-center text-sm text-stone-400 dark:text-slate-500">{t('noResults')}</p>
        ) : (
          <>
            <Section title={t('today')} chats={groups.today} {...rowProps} />
            <Section title={t('yesterday')} chats={groups.yesterday} {...rowProps} />
            <Section title={t('previous7')} chats={groups.previous7} {...rowProps} />
            <Section title={t('previous30')} chats={[...groups.previous30, ...groups.older]} {...rowProps} />
          </>
        )}
      </div>
    </div>
  )
}
