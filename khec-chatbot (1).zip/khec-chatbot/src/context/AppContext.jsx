import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react'
import { initialChats, mockProfile } from '../data/mockData'
import { generateMockResponse, simulateThinkingDelay } from '../utils/mockResponse'
import { t as translate } from '../data/translations'

const AppContext = createContext(null)

function uid(prefix = 'id') {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
}

function getSystemTheme() {
  if (typeof window === 'undefined') return 'light'
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
}

export function AppProvider({ children }) {
  const [isAuthed, setIsAuthed] = useState(() => localStorage.getItem('khec_authed') === '1')
  const [themePref, setThemePref] = useState(() => localStorage.getItem('khec_theme') || 'light')
  const [language, setLanguage] = useState(() => localStorage.getItem('khec_lang') || 'en')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false)
  const [view, setView] = useState('chat') // 'chat' | 'history' | 'settings'
  const [showSources, setShowSources] = useState(() => localStorage.getItem('khec_show_sources') !== '0')
  const [saveHistory, setSaveHistory] = useState(() => localStorage.getItem('khec_save_history') !== '0')
  const [profileMenuOpen, setProfileMenuOpen] = useState(false)

  const [chats, setChats] = useState(initialChats)
  const [activeChatId, setActiveChatId] = useState(null)
  const [sourcePanel, setSourcePanel] = useState({ open: false, sources: [], answerTitle: '' })
  const [feedbackModal, setFeedbackModal] = useState({ open: false, messageId: null, chatId: null })
  const [toast, setToast] = useState(null)
  const [isThinking, setIsThinking] = useState(false)

  const effectiveTheme = themePref === 'system' ? getSystemTheme() : themePref

  useEffect(() => {
    const root = document.documentElement
    if (effectiveTheme === 'dark') root.classList.add('dark')
    else root.classList.remove('dark')
  }, [effectiveTheme])

  useEffect(() => localStorage.setItem('khec_theme', themePref), [themePref])
  useEffect(() => localStorage.setItem('khec_lang', language), [language])
  useEffect(() => localStorage.setItem('khec_authed', isAuthed ? '1' : '0'), [isAuthed])
  useEffect(() => localStorage.setItem('khec_show_sources', showSources ? '1' : '0'), [showSources])
  useEffect(() => localStorage.setItem('khec_save_history', saveHistory ? '1' : '0'), [saveHistory])

  useEffect(() => {
    if (!toast) return
    const timer = setTimeout(() => setToast(null), 2600)
    return () => clearTimeout(timer)
  }, [toast])

  const showToast = useCallback((message) => setToast(message), [])

  const t = useCallback((key) => translate(language === 'ne' ? 'ne' : 'en', key), [language])

  const login = useCallback(() => {
    setIsAuthed(true)
  }, [])

  const logout = useCallback(() => {
    setIsAuthed(false)
    setProfileMenuOpen(false)
    setView('chat')
  }, [])

  const activeChat = useMemo(() => chats.find((c) => c.id === activeChatId) || null, [chats, activeChatId])

  const startNewChat = useCallback(() => {
    setActiveChatId(null)
    setView('chat')
    setMobileSidebarOpen(false)
  }, [])

  const openChat = useCallback((id) => {
    setActiveChatId(id)
    setView('chat')
    setMobileSidebarOpen(false)
  }, [])

  const deleteChat = useCallback(
    (id) => {
      setChats((prev) => prev.filter((c) => c.id !== id))
      if (activeChatId === id) setActiveChatId(null)
      showToast(language === 'ne' ? 'कुराकानी मेटाइयो' : 'Conversation deleted')
    },
    [activeChatId, language, showToast]
  )

  const renameChat = useCallback((id, newTitle) => {
    setChats((prev) => prev.map((c) => (c.id === id ? { ...c, title: newTitle } : c)))
  }, [])

  const sendMessage = useCallback(
    (text, opts = {}) => {
      const trimmed = text.trim()
      if (!trimmed || isThinking) return

      let chatId = activeChatId
      const userMsg = { id: uid('m'), role: 'user', text: trimmed }

      if (!chatId) {
        chatId = uid('chat')
        const newChat = {
          id: chatId,
          title: trimmed.length > 42 ? trimmed.slice(0, 42) + '…' : trimmed,
          updatedAt: new Date().toISOString(),
          messages: [userMsg],
        }
        setChats((prev) => [newChat, ...prev])
        setActiveChatId(chatId)
      } else {
        setChats((prev) =>
          prev.map((c) =>
            c.id === chatId
              ? { ...c, messages: [...c.messages, userMsg], updatedAt: new Date().toISOString() }
              : c
          )
        )
      }

      setIsThinking(true)
      const delay = opts.regenerate ? 700 : simulateThinkingDelay()
      setTimeout(() => {
        const result = generateMockResponse(trimmed)
        const botMsg = {
          id: uid('m'),
          role: 'assistant',
          text: result.text || t('fallback'),
          sources: result.text ? result.sources : [],
          isFallback: !result.text,
          feedback: null,
        }
        setChats((prev) =>
          prev.map((c) => (c.id === chatId ? { ...c, messages: [...c.messages, botMsg] } : c))
        )
        setIsThinking(false)
      }, delay)
    },
    [activeChatId, isThinking, t]
  )

  const regenerateResponse = useCallback(
    (chatId, messageId) => {
      const chat = chats.find((c) => c.id === chatId)
      if (!chat) return
      const idx = chat.messages.findIndex((m) => m.id === messageId)
      const priorUser = [...chat.messages.slice(0, idx)].reverse().find((m) => m.role === 'user')
      if (!priorUser) return

      setIsThinking(true)
      setTimeout(() => {
        const result = generateMockResponse(priorUser.text)
        setChats((prev) =>
          prev.map((c) => {
            if (c.id !== chatId) return c
            return {
              ...c,
              messages: c.messages.map((m) =>
                m.id === messageId
                  ? {
                      ...m,
                      text: result.text || t('fallback'),
                      sources: result.text ? result.sources : [],
                      isFallback: !result.text,
                      feedback: null,
                    }
                  : m
              ),
            }
          })
        )
        setIsThinking(false)
      }, 700)
    },
    [chats, t]
  )

  const setMessageFeedback = useCallback((chatId, messageId, feedback) => {
    setChats((prev) =>
      prev.map((c) =>
        c.id !== chatId
          ? c
          : { ...c, messages: c.messages.map((m) => (m.id === messageId ? { ...m, feedback } : m)) }
      )
    )
  }, [])

  const openSourcePanel = useCallback((sources, answerTitle) => {
    setSourcePanel({ open: true, sources, answerTitle })
  }, [])

  const closeSourcePanel = useCallback(() => {
    setSourcePanel((prev) => ({ ...prev, open: false }))
  }, [])

  const openFeedbackModal = useCallback((chatId, messageId) => {
    setFeedbackModal({ open: true, chatId, messageId })
  }, [])

  const closeFeedbackModal = useCallback(() => {
    setFeedbackModal({ open: false, chatId: null, messageId: null })
  }, [])

  const value = {
    isAuthed,
    login,
    logout,
    themePref,
    setThemePref,
    effectiveTheme,
    language,
    setLanguage,
    t,
    sidebarCollapsed,
    setSidebarCollapsed,
    mobileSidebarOpen,
    setMobileSidebarOpen,
    view,
    setView,
    showSources,
    setShowSources,
    saveHistory,
    setSaveHistory,
    profileMenuOpen,
    setProfileMenuOpen,
    chats,
    activeChat,
    activeChatId,
    startNewChat,
    openChat,
    deleteChat,
    renameChat,
    sendMessage,
    regenerateResponse,
    setMessageFeedback,
    isThinking,
    sourcePanel,
    openSourcePanel,
    closeSourcePanel,
    feedbackModal,
    openFeedbackModal,
    closeFeedbackModal,
    toast,
    showToast,
    profile: mockProfile,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
