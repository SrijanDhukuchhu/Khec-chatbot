// Prototype mock data for the KHEC Chatbot UI demo.
// This is sample content only and does not represent official KHEC information.

export const suggestedQuestions = [
  {
    id: 'admissions',
    icon: 'GraduationCap',
    label: 'Admissions',
    labelNe: 'भर्ना',
    question: 'How can I apply for admission?',
    questionNe: 'म भर्नाको लागि कसरी आवेदन दिन सक्छु?',
  },
  {
    id: 'examination',
    icon: 'CalendarDays',
    label: 'Examination',
    labelNe: 'परीक्षा',
    question: 'When is the next examination?',
    questionNe: 'अर्को परीक्षा कहिले हुन्छ?',
  },
  {
    id: 'academics',
    icon: 'BookOpen',
    label: 'Academics',
    labelNe: 'शैक्षिक',
    question: 'What programs does KHEC offer?',
    questionNe: 'KHEC ले कस्ता कार्यक्रमहरू प्रदान गर्छ?',
  },
  {
    id: 'scholarships',
    icon: 'Wallet',
    label: 'Scholarships',
    labelNe: 'छात्रवृत्ति',
    question: 'What scholarships are available?',
    questionNe: 'कस्ता छात्रवृत्तिहरू उपलब्ध छन्?',
  },
]

export const fallbackTopics = ['Admissions', 'Courses', 'Examination', 'Scholarships', 'Departments', 'Facilities']

// Each entry: keyword triggers -> answer + cited mock sources
export const knowledgeBase = [
  {
    keywords: ['admission', 'apply', 'admissions', 'eligibility'],
    answer:
      'To apply for a program at Khwopa Engineering College, students typically need to fulfill the eligibility criteria set by Purbanchal University and submit an application through the college admission portal along with academic transcripts and an entrance exam score. Specific requirements vary by program (Computer, Electronics & Communication, Civil Engineering, or Architecture). Please refer to the latest official admission notice for the current intake, as requirements and dates can change each year.',
    sources: [
      { title: 'KHEC Admission Notice 2026', page: 3, type: 'PDF', excerpt: 'Students seeking admission to undergraduate programs must fulfill the eligibility requirements set by the university and submit required documents before the stated deadline.' },
      { title: 'KHEC Academic Information Handbook', page: 12, type: 'PDF', excerpt: 'Admission to each department is based on merit rank in the common entrance examination, followed by document verification and fee submission.' },
    ],
  },
  {
    keywords: ['exam', 'examination', 'routine', 'schedule', 'test'],
    answer:
      'Examination routines at KHEC are published on the notice board and college portal roughly 2–3 weeks before the exam period begins. The next semester examination is tentatively scheduled for early 2026, but the exact routine, including subject-wise dates and time slots, is confirmed closer to the date by the Examination Section.',
    sources: [
      { title: 'Examination Routine 2026', page: 1, type: 'Notice', excerpt: 'The semester end examination for all undergraduate programs will commence as per the routine published by the Examination Section.' },
      { title: 'KHEC Academic Calendar', page: 2, type: 'PDF', excerpt: 'Examination periods fall at the end of each semester, followed by a result publication window of approximately four to six weeks.' },
    ],
  },
  {
    keywords: ['scholarship', 'financial aid', 'fee waiver', 'stipend'],
    answer:
      'KHEC offers a limited number of merit-based and need-based scholarships, including partial fee waivers for top-ranking students in the entrance examination and ongoing semester results. Some scholarships are coordinated with government and university-level programs. Interested students should check the scholarship notice published each academic year and submit an application with supporting documents to the Student Welfare office.',
    sources: [
      { title: 'KHEC Scholarship Guidelines', page: 5, type: 'PDF', excerpt: 'Merit scholarships are awarded to students ranking within the top positions of the entrance examination for each program.' },
      { title: 'Student Welfare Notice Board Archive', page: 1, type: 'Notice', excerpt: 'Need-based fee waivers are reviewed annually by the scholarship committee based on submitted financial documentation.' },
    ],
  },
  {
    keywords: ['course', 'courses', 'program', 'programs', 'bct', 'bce', 'bex', 'barch', 'degree'],
    answer:
      'KHEC currently offers undergraduate programs in Computer Engineering (BCT), Electronics & Communication Engineering (BEX), Civil Engineering (BCE), and Architecture (B.Arch), each affiliated with Purbanchal University. Programs typically run 4 years (8 semesters) for engineering degrees and 5 years for Architecture, combining coursework, laboratory work, and a final-year project.',
    sources: [
      { title: 'KHEC Academic Information Handbook', page: 8, type: 'PDF', excerpt: 'The college offers four-year undergraduate engineering programs and a five-year program in Architecture, each structured across semesters.' },
    ],
  },
  {
    keywords: ['department', 'departments', 'faculty', 'hod', 'staff'],
    answer:
      'KHEC is organized into departments for Computer Engineering, Electronics & Communication Engineering, Civil Engineering, Architecture, and Applied Sciences (which handles first-year foundational courses). Each department is led by a Head of Department and includes dedicated faculty, teaching assistants, and laboratory staff supporting coursework and research.',
    sources: [
      { title: 'KHEC Department Directory', page: 1, type: 'Web Page', excerpt: 'Each academic department maintains its own laboratories, faculty roster, and project mentorship structure for undergraduate students.' },
    ],
  },
  {
    keywords: ['library', 'books', 'reading room'],
    answer:
      'The KHEC library provides a collection of engineering and architecture reference books, past exam question banks, journals, and a quiet reading room for students. Some digital resources and e-journal access may also be available through the university library network. Library hours generally follow college working hours, with extended hours during examination periods.',
    sources: [
      { title: 'KHEC Library Services Guide', page: 2, type: 'PDF', excerpt: 'The central library maintains reference collections for all engineering and architecture programs, alongside a dedicated examination-period reading schedule.' },
    ],
  },
  {
    keywords: ['contact', 'address', 'phone', 'email', 'location', 'where is khec'],
    answer:
      'Khwopa Engineering College is located in Libali, Bhaktapur, Nepal. For official inquiries, it is best to contact the college administration office directly through the phone numbers and email listed on the official KHEC website, as contact details are periodically updated.',
    sources: [
      { title: 'KHEC Contact Directory', page: 1, type: 'Web Page', excerpt: 'The college administration office handles general inquiries, admissions coordination, and correspondence for all departments.' },
    ],
  },
  {
    keywords: ['fee', 'fees', 'tuition', 'cost', 'payment'],
    answer:
      'Tuition and other fees at KHEC vary by program and are typically payable per semester, with separate charges for tuition, examination, library, and laboratory usage. Fee structures are reviewed periodically, so students should confirm the current semester fee with the Accounts Section rather than relying on previous years\' figures.',
    sources: [
      { title: 'KHEC Fee Structure Notice', page: 1, type: 'Notice', excerpt: 'Semester fees are payable within the deadline announced by the Accounts Section at the start of each semester.' },
    ],
  },
  {
    keywords: ['hostel', 'accommodation', 'dorm', 'residence'],
    answer:
      'Limited hostel accommodation may be available for out-of-valley students, subject to seat availability, and is generally allocated on a first-come, first-served or need basis. Many students also arrange nearby private accommodation in Bhaktapur. Interested students should inquire with the college administration about current hostel capacity and application procedures.',
    sources: [
      { title: 'KHEC Student Services Handbook', page: 6, type: 'PDF', excerpt: 'Hostel seats are limited and prioritized for students traveling from outside the Kathmandu Valley, subject to availability each academic year.' },
    ],
  },
]

export const initialChats = [
  {
    id: 'c1',
    title: 'Admission Requirements',
    updatedAt: daysAgo(0, 2),
    messages: seedMessages('admission'),
  },
  {
    id: 'c2',
    title: 'Exam Routine 2026',
    updatedAt: daysAgo(0, 6),
    messages: seedMessages('examination'),
  },
  {
    id: 'c3',
    title: 'Scholarship Information',
    updatedAt: daysAgo(1, 1),
    messages: seedMessages('scholarship'),
  },
  {
    id: 'c4',
    title: 'BCT Courses',
    updatedAt: daysAgo(3, 0),
    messages: seedMessages('course'),
  },
  {
    id: 'c5',
    title: 'College Facilities',
    updatedAt: daysAgo(9, 0),
    messages: seedMessages('library'),
  },
  {
    id: 'c6',
    title: 'Department Information',
    updatedAt: daysAgo(21, 0),
    messages: seedMessages('department'),
  },
]

function daysAgo(days, hours = 0) {
  const d = new Date()
  d.setDate(d.getDate() - days)
  d.setHours(d.getHours() - hours)
  return d.toISOString()
}

function seedMessages(keyword) {
  const entry = knowledgeBase.find((k) => k.keywords.includes(keyword))
  const userTexts = {
    admission: 'What are the admission requirements for Computer Engineering?',
    examination: 'When is the next examination scheduled?',
    scholarship: 'What scholarships are available for engineering students?',
    course: 'What courses are included in the BCT program?',
    library: 'What facilities does the KHEC library offer?',
    department: 'Which departments does KHEC have?',
  }
  return [
    { id: 'm1', role: 'user', text: userTexts[keyword] },
    {
      id: 'm2',
      role: 'assistant',
      text: entry?.answer || 'Here is what I found in the KHEC knowledge base.',
      sources: entry?.sources || [],
    },
  ]
}

export const mockProfile = {
  name: 'Anish Shrestha',
  username: 'anish.shrestha',
  email: 'anish.shrestha@example.edu.np',
  role: 'Student',
  department: 'Computer Engineering',
}
