import React from 'react'
import { AppProvider, useApp } from './context/AppContext'
import Login from './pages/Login'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import Dashboard from './pages/Dashboard'
import History from './pages/History'
import Settings from './pages/Settings'
import SourcePanel from './components/SourcePanel'
import FeedbackModal from './components/FeedbackModal'
import Toast from './components/Toast'

function Shell() {
  const { isAuthed, view, sourcePanel } = useApp()

  if (!isAuthed) return <Login />

  return (
    <div className="flex h-[100dvh] w-full overflow-hidden bg-stone-50 text-stone-800 dark:bg-slate-950 dark:text-slate-100">
      <Sidebar />
      <div
        className={`flex min-w-0 flex-1 flex-col transition-[margin] duration-200 ${
          sourcePanel.open ? 'lg:mr-[380px]' : ''
        }`}
      >
        <Header />
        <main className="flex min-h-0 flex-1 flex-col overflow-hidden">
          {view === 'chat' && <Dashboard />}
          {view === 'history' && <History />}
          {view === 'settings' && <Settings />}
        </main>
      </div>
      <SourcePanel />
      <FeedbackModal />
      <Toast />
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  )
}
