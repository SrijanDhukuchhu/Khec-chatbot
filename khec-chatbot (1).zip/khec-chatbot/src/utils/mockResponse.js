import { knowledgeBase } from '../data/mockData'

// Very simple keyword matcher that simulates a RAG retrieval step.
// Real implementation would embed the query and search a vector store.
export function generateMockResponse(question) {
  const q = question.toLowerCase()
  const match = knowledgeBase.find((entry) => entry.keywords.some((kw) => q.includes(kw)))

  if (match) {
    return {
      text: match.answer,
      sources: match.sources,
    }
  }

  return {
    text: null, // signals fallback state to the UI
    sources: [],
  }
}

export function simulateThinkingDelay() {
  return 900 + Math.random() * 700
}
