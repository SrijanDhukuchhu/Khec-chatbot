# KHEC Chatbot — UI Prototype

A ChatGPT-style AI assistant interface for **Khwopa Engineering College (KHEC)**, built as the
front-end prototype for a final-year project. This is a fully interactive UI with realistic mock
data and simulated chatbot responses — there is **no backend or live AI model** yet. It's designed
to demonstrate how a future Retrieval-Augmented Generation (RAG) system would look and feel.

## Tech stack

- React 18 + Vite
- Tailwind CSS
- lucide-react icons
- Local component state + `localStorage` (no backend, no external API calls)

## Getting started

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

To create a production build:

```bash
npm run build
npm run preview
```

## What's implemented

- **Login screen** — any email/username + password logs you in (prototype only, no real auth).
- **Welcome / dashboard screen** — four suggested-question cards that populate the chat.
- **Chat interface** — user/assistant bubbles, typing indicator, like/dislike, copy, and
  regenerate on every response.
- **Keyword-based mock chatbot** (`src/utils/mockResponse.js`) — recognizes topics like
  admissions, examinations, scholarships, courses, departments, library, fees, hostel, and
  contact info; anything else triggers a graceful "not found in knowledge base" fallback with
  suggested topics.
- **RAG source panel** — relevant answers show inline source previews plus a **View sources**
  button that opens a slide-in panel with document title, page number, source type, and excerpt —
  a visual stand-in for a real retrieval pipeline.
- **Chat history** — grouped by Today / Yesterday / Previous 7 Days / Previous 30 Days, with
  search, rename, and delete.
- **Feedback system** — disliking a response opens a reason modal (incorrect info, not relevant,
  incomplete, incorrect source, other) with an optional note.
- **Settings** — language, theme, show-sources toggle, save-history toggle, and account actions.
- **Bilingual UI** — English and नेपाली, switchable from the header, login screen, or settings.
- **Dark mode** — light / dark / system, persisted for the session via `localStorage`.
- **Responsive layout** — collapsible sidebar on desktop/tablet, hamburger drawer on mobile.

## Project structure

```text
src/
├── components/      Reusable UI building blocks (Sidebar, ChatWindow, ChatMessage, ChatInput,
│                    SourcePanel, SourceCard, SuggestedQuestion, FeedbackModal, Header,
│                    ProfileMenu, TypingIndicator, Toast, Logo)
├── pages/           Login, Dashboard, History, Settings
├── context/         AppContext.jsx — global state (auth, theme, language, chats, settings)
├── data/            mockData.js (KHEC mock content), translations.js (EN/NE strings)
├── utils/           mockResponse.js — keyword-matching mock "RAG" responder
├── App.jsx
├── main.jsx
└── index.css
```

## Notes for the final-year report

- All KHEC facts shown in the chatbot (admissions, fees, scholarships, etc.) are **illustrative
  mock content**, not official college information — this is called out in the UI footer and
  should be called out in your report too.
- The source panel is wired to static mock documents; connecting it to a real vector store /
  document index is the next milestone described in your project proposal.
- `npm run dev` requires no network access beyond the initial `npm install`; there are no live API
  keys or external services involved.
