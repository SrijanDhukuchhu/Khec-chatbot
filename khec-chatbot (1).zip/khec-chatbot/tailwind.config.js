/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        brand: {
          50: '#eef2fb',
          100: '#d7e0f4',
          200: '#adc0e8',
          300: '#7d9bd9',
          400: '#4e75c8',
          500: '#2f56ac',
          600: '#1f3f8c',
          700: '#16326b',
          800: '#112552',
          900: '#0c1a3a',
        },
        terracotta: {
          50: '#fbf1ea',
          100: '#f4dcc9',
          200: '#e8b78e',
          300: '#d8905c',
          400: '#c2703d',
          500: '#a85a2d',
          600: '#894722',
        },
      },
      boxShadow: {
        soft: '0 1px 2px 0 rgba(16, 24, 40, 0.04), 0 1px 3px 0 rgba(16, 24, 40, 0.06)',
        panel: '-4px 0 24px -8px rgba(16, 24, 40, 0.15)',
      },
      keyframes: {
        blink: {
          '0%, 80%, 100%': { opacity: 0.25, transform: 'scale(0.85)' },
          '40%': { opacity: 1, transform: 'scale(1)' },
        },
        slideIn: {
          from: { transform: 'translateX(100%)' },
          to: { transform: 'translateX(0)' },
        },
        slideInLeft: {
          from: { transform: 'translateX(-100%)' },
          to: { transform: 'translateX(0)' },
        },
        fadeUp: {
          from: { opacity: 0, transform: 'translateY(6px)' },
          to: { opacity: 1, transform: 'translateY(0)' },
        },
      },
      animation: {
        blink: 'blink 1.3s infinite ease-in-out both',
        slideIn: 'slideIn 0.25s cubic-bezier(0.32, 0.72, 0, 1)',
        slideInLeft: 'slideInLeft 0.25s cubic-bezier(0.32, 0.72, 0, 1)',
        fadeUp: 'fadeUp 0.25s ease-out',
      },
    },
  },
  plugins: [],
}
